# Basic_Banking_System
This project is done as a part of The Sparks Foundation Internship  #GRIPNOV2020

[![email](https://img.shields.io/static/v1.svg?label=Basic_Banking&message=System&color=grey&logo=gmail&style=flat&logoColor=white&colorA=critical)](https://github.com/neha07kumari/Basic_Banking_System) [![outlook](https://img.shields.io/static/v1.svg?label=Outlook&message=Template&color=grey&logo=microsoft-outlook&style=flat&logoColor=white&colorA=dodgerblue)](https://github.com/neha07kumari/Basic_Banking_System)




## Technology Stack Used

![HTML](https://img.shields.io/badge/frontend-html-orange.svg?logo=html5&style=flat-square) 
![CSS](https://img.shields.io/badge/frontend-css-yellowgreen.svg?logo=css3&style=flat-square)
![Mysql](https://img.shields.io/badge/backend-Mysql-pink.svg?logo=Mysql&style=flat-square)
![PHP](https://img.shields.io/badge/backend-PHP-yellow.svg?logo=PHP&style=flat-square)

- Front End - **HTML**, **CSS**
- Back End - **Mysql**, **PHP**
### Still need help?

```

  if (needHelp === true) {
     var emailId = "2911nehakumari@gmail.com";
     // email is the best way to reach out to me.
     sendEmail(emailId);
  }

```

  [![Instagram](https://img.shields.io/static/v1.svg?label=follow&message=@neha7_kashyap&color=grey&logo=instagram&style=flat&logoColor=white&colorA=critical)](https://www.instagram.com/neha7_kashyap/) [![LinkedIn](https://img.shields.io/static/v1.svg?label=connect&message=@neha-kumari-09415a16b/&color=9cf&logo=linkedin&style=flat&logoColor=white&colorA=blue)](https://www.linkedin.com/in/neha-kumari-09415a16b/) [![Twitter](https://img.shields.io/static/v1.svg?label=connect&message=@Neha_kumari_7&color=grey&logo=twitter&style=flat&logoColor=white&colorA=critical)](https://twitter.com/Neha_kumari_7)

***Glad to see you here! Show some love by [starring](https://github.com/neha07kumari/Basic_Banking_System/) this repo.***

-----

```

  if (isAwesome) {
    // thanks in advance :p
    starThisRepository();
  }

```

******
